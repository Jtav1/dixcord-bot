import express from 'express';
import db from '../config/db.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();

// All routes require auth
router.use(authenticate);

// GET /api/posts - list current user's posts
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT id, user_id, title, body, created_at, updated_at FROM posts WHERE user_id = ? ORDER BY updated_at DESC',
      [req.user.id]
    );
    res.json({ posts: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to list posts' });
  }
});

// GET /api/posts/:id - get one post
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT id, user_id, title, body, created_at, updated_at FROM posts WHERE id = ? AND user_id = ?',
      [req.params.id, req.user.id]
    );
    if (rows.length === 0) return res.status(404).json({ error: 'Post not found' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to get post' });
  }
});

// POST /api/posts - create post
router.post('/', async (req, res) => {
  try {
    const { title, body } = req.body;
    if (!title) return res.status(400).json({ error: 'Title is required' });
    const [result] = await db.query(
      'INSERT INTO posts (user_id, title, body) VALUES (?, ?, ?)',
      [req.user.id, title, body || null]
    );
    const [rows] = await db.query(
      'SELECT id, user_id, title, body, created_at, updated_at FROM posts WHERE id = ?',
      [result.insertId]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create post' });
  }
});

// PUT /api/posts/:id - update post
router.put('/:id', async (req, res) => {
  try {
    const { title, body } = req.body;
    const [existing] = await db.query('SELECT id FROM posts WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
    if (existing.length === 0) return res.status(404).json({ error: 'Post not found' });
    const updates = [];
    const values = [];
    if (title !== undefined) { updates.push('title = ?'); values.push(title); }
    if (body !== undefined) { updates.push('body = ?'); values.push(body); }
    if (updates.length === 0) return res.status(400).json({ error: 'No fields to update' });
    values.push(req.params.id);
    await db.query(`UPDATE posts SET ${updates.join(', ')} WHERE id = ?`, values);
    const [rows] = await db.query(
      'SELECT id, user_id, title, body, created_at, updated_at FROM posts WHERE id = ?',
      [req.params.id]
    );
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to update post' });
  }
});

// DELETE /api/posts/:id
router.delete('/:id', async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM posts WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Post not found' });
    res.status(204).send();
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to delete post' });
  }
});

export default router;
